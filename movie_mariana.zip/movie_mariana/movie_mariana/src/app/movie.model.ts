export class Movie {
    title: string;
    year: string;
    released: string;
    runtime: string;
    genre: string[];
    poster: string;
    Ratings: { source: string; value: string }[];
    meta_score: string;

    constructor(){
        this.title = '';
        this.year = '';
        this.released = '';
        this.runtime = '';
        this.genre = [];
        this.poster = '';
        this.Ratings = [];
        this.meta_score = '';
    }
  }

  