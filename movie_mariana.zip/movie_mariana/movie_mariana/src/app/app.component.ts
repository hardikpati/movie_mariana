import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Movie } from './movie.model';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'movie_mariana';

  genreFilterControl = new FormControl('');

  moviesByDate: { date: string; movies: Movie[] }[] = [];

  moviesData: any = []
  allGenres: string[] = [];

  selectedGenres: string[] = [];

  filteredData: any[] = [];

  searchText: string = '';

  constructor(private http: HttpClient) {

  }

  ngOnInit(): void {
    const url = 'http://localhost:3000/jsonBodyList'
    this.http.get(url).subscribe((res) => {
      this.moviesData = res
      console.log(this.moviesData[0].movies[0].title)

      this.populateGenres();

      this.filteredData = this.moviesData;
    })

  }

  populateGenres() {

    const genresSet = new Set<string>();

    this.moviesData.forEach((data: any) => {

      data.movies.forEach((movie: any) => {

        movie.genre.forEach((genre: string) => genresSet.add(genre));

      });

    });
    
    this.allGenres = Array.from(genresSet);
    console.log(this.allGenres)

  }




  applyGenreFilter() {

    if (this.selectedGenres.length === 0) {

      this.filteredData = this.moviesData;

    } else {

      this.filteredData = this.moviesData.map((data: any) => ({

        date: data.date,

        movies: data.movies.filter((movie: any) =>

          movie.genre.some((genre: string) => this.selectedGenres.includes(genre))

        ),

      }));

    }

  }




  applyTitleSearch() {

    if (this.searchText.trim() === '') {

      this.filteredData = this.moviesData;

    } else {

      const searchTerm = this.searchText.toLowerCase();

      this.filteredData = this.moviesData.map((data: any) => ({

        date: data.date,

        movies: data.movies.filter((movie: any) =>

          movie.title.toLowerCase().includes(searchTerm)

        ),

      }));

    }
}
}

