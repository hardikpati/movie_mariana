import { Pipe, PipeTransform } from '@angular/core';


@Pipe({

  name: 'genreFilter'

})

export class GenreFilterPipe implements PipeTransform {

  transform(movies: any[], selectedGenre: string): any[] {

    if (!selectedGenre || selectedGenre === '') {

      return movies;

    }

    return movies.filter(movie => movie.genres.includes(selectedGenre));

  }

}